insert into person_list (name, email) value( 'Niko', 'nicolas.asinovich@gmail.com');
insert into person_list (name, email) value( 'Future work', 'test-task@itspartner.net');
